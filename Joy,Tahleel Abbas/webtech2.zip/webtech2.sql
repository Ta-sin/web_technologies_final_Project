-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2020 at 12:24 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtech2`
--

-- --------------------------------------------------------

--
-- Table structure for table `doclist`
--

CREATE TABLE `doclist` (
  `id` int(11) NOT NULL,
  `docName` varchar(110) NOT NULL,
  `docCat` varchar(110) NOT NULL,
  `status` varchar(110) NOT NULL,
  `book` varchar(110) NOT NULL,
  `phone` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doclist`
--

INSERT INTO `doclist` (`id`, `docName`, `docCat`, `status`, `book`, `phone`) VALUES
(1, 'Abdulla', 'Cardiologists', 'Available', 'Yes', '+8801778518330'),
(2, 'Abdulla', 'Cardiologists', 'Available', 'Yes', '+8801778518330'),
(3, 'Momen', 'Endocrinologists', 'Available', 'Yes', '+8801778518377'),
(4, 'Nafiz', 'Cardiologists', 'Available', 'No', '+8801778518567'),
(5, 'Ababss', 'Dermatologists', 'Available', 'Yes', '+8801778518760'),
(6, 'Dip', 'Cardiologists', 'Available', 'No', '+8801778518330'),
(7, 'Badol', 'Endocrinologists', 'Available', 'Yes', '+8801778518364'),
(8, 'Rakib', 'Dermatologists', 'Available', 'Yes', '+8801778518311');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `docName` varchar(110) NOT NULL,
  `sector` varchar(110) NOT NULL,
  `visited` varchar(110) NOT NULL,
  `pres` varchar(110) NOT NULL,
  `reports` varchar(110) NOT NULL,
  `sr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `docName`, `sector`, `visited`, `pres`, `reports`, `sr`) VALUES
(1, 'Abdulla', 'Cardiologists', '21-07-2019', 'Prescription', 'Reports', 1),
(1, 'Abdulla', 'Cardiologists', '29-07-2019', 'Prescription', 'Reports', 2),
(1, 'Abdulla', 'Cardiologists', '2-08-2019', 'Prescription', 'Reports', 3),
(1, 'Ababss', 'Dermatologists', '4-08-2019', 'Prescription', 'Reports', 4),
(1, 'Abdulla', 'Cardiologists', '8-11-2019', 'Prescription', 'Reports', 5),
(1, 'Ababss', 'Dermatologists', '14-12-2019', 'Prescription', 'Reports', 6),
(2, 'Abdulla', 'Cardiologists', '129-04-2020', 'Prescription', 'Reports', 7),
(2, 'Abdulla', 'Cardiologists', '21-05-2020', 'Prescription', 'Reports', 8),
(2, 'Ababss', 'Dermatologists', '14-06-2020', 'Prescription', 'Reports', 9),
(2, 'Abdulla', 'Cardiologists', '18-06-2020', 'Prescription', 'Reports', 10),
(2, 'Ababss', 'Dermatologists', '14-12-2020', 'Prescription', 'Reports', 11);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `sr` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `age` varchar(3) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `bloodGroup` varchar(5) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `image` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`sr`, `name`, `age`, `gender`, `bloodGroup`, `phone`, `password`, `image`) VALUES
(1, 'Saad', '51', 'Male', 'B+', '01778518304', '1234', 'saad'),
(2, 'Joy', '21', 'Female', 'C+', '01303536811', '1234', 'joy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doclist`
--
ALTER TABLE `doclist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`sr`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doclist`
--
ALTER TABLE `doclist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
