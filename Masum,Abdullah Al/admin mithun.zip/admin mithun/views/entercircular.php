<?php
  session_start();

  if(!isset($_SESSION['name']))
  {
    header("location:login.php");
  }
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Circular create</title>
</head>
<body>

	<form method="POST" action="../php/postjobtodb.php">
		<fieldset>
			<legend>Enter Circular</legend>
			<table>
				<tr>
					<td>
						Name of position:
					</td>
					<td>
						<input type="text" name="position">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Department/division:
					</td>
					<td>
						<input type="text" name="dept">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Functions:
					</td>
					<td>
						<input type="text" name="functions">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Employment Type:
					</td>
					<td>
						<input type="text" name="emtype">
					</td>
					
					
				</tr>
				<tr>
					<td>
						 Office Timing:
					</td>
					<td>
						<input type="text" name="officetime">
					</td>
					
					
				</tr>
				<tr>
					<td>
						 Job Level:
					</td>
					<td>
						<input type="text" name="joblevel">
					</td>
					
					
				</tr>
				<tr>
					<td>
						  Reports To :
					</td>
					<td>
						<input type="text" name="reports">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Office Location:
					</td>
					<td>
						<input type="text" name="officeloc">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Salary Range:
					</td>
					<td>
						<input type="text" name="salary">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Age Limit :
					</td>
					<td>
						<input type="text" name="agelimit">
					</td>
					
					
				</tr>
				<tr>
					<td>
						 Educational Requirements :
					</td>
					<td>
						<input type="text" name="edureq">
					</td>
					
					
				</tr>
				<tr>
					<td>
						 Experience Requirements :
					</td>
					<td>
						<input type="text" name="expreq">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Job Responsibilities :
					</td>
					<td>
						<input type="text" name="jobrep1">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Job Responsibilities:
					</td>
					<td>
						<input type="text" name="jobrep2">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Job Responsibilities:
					</td>
					<td>
						<input type="text" name="jobrep3">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Job Responsibilities:
					</td>
					<td>
						<input type="text" name="jobrep4">
					</td>
					
					
				</tr>
				<tr>
					<td>
						 Additional Job Responsibilities :
					</td>
					<td>
						<input type="text" name="adddjobrep">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Additional Job Responsibilities :
					</td>
					<td>
						<input type="text" name="adddjobrep2">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Additional Job Responsibilities :
					</td>
					<td>
						<input type="text" name="adddjobrep3">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Additional Job Responsibilities :
					</td>
					<td>
						<input type="text" name="adddjobrep4">
					</td>


					
					
				</tr>

				<tr>
					<td>
						Technical Competencies :
					</td>
					<td>
						<input type="text" name="techcom">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Technical Competencies :
					</td>
					<td>
						<input type="text" name="techcom2">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Technical Competencies :
					</td>
					<td>
						<input type="text" name="techcom3">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Behavioral Competencies:
					</td>
					<td>
						<input type="text" name="behavecom">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Behavioral Competencies:
					</td>
					<td>
						<input type="text" name="behavecom2">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Behavioral Competencies:
					</td>
					<td>
						<input type="text" name="behavecom3">
					</td>
					
					
				</tr>
				<tr>
					<td>
						 Other Benefits :
					</td>
					<td>
						<input type="text" name="benefits">
					</td>
					
					
				</tr>
				<tr>
					<td>
						Council Registration Requirements :
					</td>
					<td>
						<input type="text" name="councilreq">
					</td>
					
					
				</tr>

				<tr>
					<td align="left">
						<input type="submit" name="submit" value="Submit">
					</td>
					<td>
						<a href="postjob.php" alig
						right>Go Back</a>
					</td>
				</tr>
				



			</table>
		</fieldset>
	</form>

</body>
